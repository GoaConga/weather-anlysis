import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from urllib.request import urlopen

readme = 'https://www1.ncdc.noaa.gov/pub/data/ghcn/daily/readme.txt'
station = 'https://www1.ncdc.noaa.gov/pub/data/ghcn/daily/ghcnd-stations.txt'

#for line in urlopen(readme):
    #print(line)

def convert(lst):
    return ([i for item in lst for i in item.split()])

def before_sort_graph(xplot_lst,yplot_lst):
    plt.bar(xplot_lst,yplot_lst)
    plt.show()

def graph_sort(state,s_state):
    with open('plot_x.txt', 'w') as f:
        for lined in urlopen(station):
            str_lin = str(lined, 'UTF-8')
            contents = str_lin
            lst = [contents]
            xcon_lst = convert(lst)
            i = 0
            while i is not len(xcon_lst):
                x = xcon_lst[i]
                i += 1
                if x == state or x == s_state:
                    f.write(xcon_lst[1] + '\n')

    with open('plot_y.txt', 'w') as f:
        for lined in urlopen(station):
            str_lin = str(lined, 'UTF-8')
            contents = str_lin
            lst = [contents]
            ycon_lst = convert(lst)
            i = 0
            while i is not len(ycon_lst):
                y = ycon_lst[i]
                i += 1
                if y == state or y == s_state:
                    f.write(ycon_lst[2] + '\n')

    with open('plot_x.txt') as xf:
        x_con = xf.read()
    xlst = [x_con]
    xplot_lst = convert(xlst)
    xplot_copy = np.sort(xplot_lst)[::-1]
    print(xplot_copy)

    with open('plot_y.txt') as yf:
        y_con = yf.read()
    ylst = [y_con]
    yplot_lst = convert(ylst)
    yplot_copy = np.sort(yplot_lst)[::-1]
    print(yplot_copy)

    before_sort_graph(xplot_lst,yplot_lst)

    plt.rcParams["figure.figsize"] = [7.50, 3.50]
    plt.rcParams["figure.autolayout"] = True
    df = pd.DataFrame(
        dict(
            xplot_lst=convert(xlst),
            yplot_lst=convert(ylst)
        )
    )

    plt.subplot(121)
    plt.bar('xplot_lst', 'yplot_lst', data=df, color='red')
    plt.subplot(122)
    df_sorted = df.sort_values('yplot_lst')
    plt.bar('xplot_lst', 'yplot_lst', data=df_sorted, color='orange')
    plt.title(state +','+ s_state)
    plt.show()

graph_sort('CA','CALIFORNIA')
graph_sort('PASADENA','SOUTH PASADENA')






